/*****************
Name : Pritesh suryawanshi
Date : 1/8/2024
Description : Address Book Project
Sample input : ./abk
Sample output :
******************/
#include <stdio.h>
#include <stdlib.h>
#include "abk.h"

int main(void) {
    int choice;

    if (load_contacts(contacts, &contact_count) == FAILURE) {
        printf("No contacts loaded. Starting with an empty address book.\n");
    }

    while (1) {
        printf("\nAddress Book Application\n");
        printf("1. Add a new contact\n");
        printf("2. Display all contacts\n");
        printf("3. Search a contact\n");
        printf("4. Delete a contact\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                add_contact();
                break;
            case 2:
                display_contacts();
                break;
            case 3:
                search_contact();
                break;
            case 4:
                delete_contact();
                break;
            case 5:
                if (save_contacts(contacts, contact_count) == SUCCESS) {
                    printf("Contacts saved successfully!\n");
                } else {
                    printf("Failed to save contacts.\n");
                }
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice, please try again.\n");
                break;
        }
    }

    return 0;
}

