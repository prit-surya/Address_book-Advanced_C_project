/*****************
Name : Pritesh suryawanshi
Date :
Description :
Sample input :
Sample output :
******************/
#include <stdio.h>
#include "abk.h"

#define ABK_LOG_FILE "ABK.LOG"

// Function to log messages to a file and display them on the console
return_t abk_log(int result, char *msgtype, char *msg) {
    FILE *fp = fopen(ABK_LOG_FILE, "a");
    if (fp == NULL) {
        perror(ABK_LOG_FILE);
        return result;
    }

    fprintf(fp, "%s: %s %s\n", msgtype, __TIME__, msg);
    fclose(fp);

    printf("%s: %s %s\n", msgtype, __TIME__, msg);
    WAIT_FOR_ENTER_KEY;
    return result;
}

return_t log_info(return_t result, char *msg) {
    return abk_log(result, "INFO", msg);
}

return_t log_warn(return_t result, char *msg) {
    return abk_log(result, "WARN", msg);
}

return_t log_error(return_t result, char *msg) {
    return abk_log(result, "ERROR", msg);
}

