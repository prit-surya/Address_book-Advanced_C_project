/*****************
Name : Pritesh suryawanshi
Date :
Description :
Sample input :
Sample output :
******************/

#include <stdio.h>
#include <string.h>
#include "abk.h"

void add_contact() {
    if (contact_count < MAX_CONTACTS) {
        printf("Enter name: ");
        scanf("%s", contacts[contact_count].name);
        printf("Enter phone: ");
        scanf("%s", contacts[contact_count].phone);
        printf("Enter email: ");
        scanf("%s", contacts[contact_count].email);
        contact_count++;
        printf("Contact added successfully!\n");
    } else {
        printf("Address book is full!\n");
    }
}

void display_contacts() {
    if (contact_count == 0) {
        printf("No contacts to display.\n");
        return;
    }

    for (int i = 0; i < contact_count; i++) {
        printf("%d. Name: %s, Phone: %s, Email: %s\n", i+1, contacts[i].name, contacts[i].phone, contacts[i].email);
    }
}

void search_contact() {
    char search_name[50];
    printf("Enter the name to search: ");
    scanf("%s", search_name);

    for (int i = 0; i < contact_count; i++) {
        if (strcmp(search_name, contacts[i].name) == 0) {
            printf("Contact found: %s, Phone: %s, Email: %s\n", contacts[i].name, contacts[i].phone, contacts[i].email);
            return;
        }
    }
    printf("Contact not found.\n");
}

void delete_contact() {
    char delete_name[50];
    printf("Enter the name of the contact to delete: ");
    scanf("%s", delete_name);

    for (int i = 0; i < contact_count; i++) {
        if (strcmp(delete_name, contacts[i].name) == 0) {
            for (int j = i; j < contact_count - 1; j++) {
                contacts[j] = contacts[j + 1];
            }
            contact_count--;
            printf("Contact deleted successfully.\n");
            return;
        }
    }
    printf("Contact not found.\n");
}
 
