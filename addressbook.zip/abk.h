#ifndef ABK_H
#define ABK_H

// Return type enumeration
typedef enum {
    SUCCESS = 0,
    FAILURE = 1
} return_t;

// Max number of contacts
#define MAX_CONTACTS 100

// Structure for storing contact information
typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

// Function prototypes
return_t load_contacts(Contact *contacts, int *count);
return_t save_contacts(Contact *contacts, int count);
void add_contact();
void display_contacts();
void search_contact();
void delete_contact();

// Global variables
extern Contact contacts[MAX_CONTACTS];
extern int contact_count;

// Macro to pause the program and wait for the user to press Enter
#define WAIT_FOR_ENTER_KEY { printf("Press Enter to continue...\n"); getchar(); getchar(); }

#endif /* ABK_H */

