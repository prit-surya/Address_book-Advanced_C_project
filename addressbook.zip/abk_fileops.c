/*****************
Name : Pritesh suryawanshi
Date :
Description :
Sample input :
Sample output :
******************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abk.h"

#define CONTACTS_FILE "contacts.dat"
Contact contacts[MAX_CONTACTS];
int contact_count = 0;

// Function to load contacts from a file
return_t load_contacts(Contact *contacts, int *count) {
    FILE *fp = fopen(CONTACTS_FILE, "r");
    if (fp == NULL) {
        perror("Unable to open contacts.dat");
        return FAILURE;
    }

    int i = 0;
    while (fscanf(fp, "%s %s %s", contacts[i].name, contacts[i].phone, contacts[i].email) != EOF) {
        i++;
    }
    *count = i;
    fclose(fp);
    return SUCCESS;
}

// Function to save contacts to a file
return_t save_contacts(Contact *contacts, int count) {
    FILE *fp = fopen(CONTACTS_FILE, "w");
    if (fp == NULL) {
        perror("Unable to open contacts.dat");
        return FAILURE;
    }

    for (int i = 0; i < count; i++) {
        fprintf(fp, "%s %s %s\n", contacts[i].name, contacts[i].phone, contacts[i].email);
    }

    fclose(fp);
    return SUCCESS;
}

